# -*- coding: utf-8 -*-
"""
Created on Sat Jul 14 10:55:01 2018

@author: ranas
"""


import os, sys
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT_PATH)
from func_class_package.load_images import load_images, load_test_images
from func_class_package.preprocess_image import augment_data, rgb2gray, stdimage, pcafun
from  func_class_package.cnn_class import convnet_class
from  func_class_package.rf_class import rf_class
from  func_class_package.ensemble_model import ensemble_model, model_perf

#class datapath:
#    def __init__(self,path_train_1,path_train_0,path_val_1,path_val_0):
#        self.default_path = os.getcwd()
        
        
default_path = ROOT_PATH
path_train_1 = os.path.join(default_path,"Images","car-train")
path_train_0 = os.path.join(default_path,"Images","notcar-train")
path_val_0 = os.path.join(default_path,"Images","notcar-validate")
path_val_1 = os.path.join(default_path,"Images","car-validate")

## To change directory
#os.chdir(path)
imsize = 50
maxfeature = 255
## Load input data

if (os.path.exists("training_data.npy")):
    training_data = np.load("training_data.npy")
else:
    training_data_1 = load_images(path_train_1,[1,0],imsize)
    training_data_0 = load_images(path_train_0,[0,1],imsize)
    training_data = training_data_1 + training_data_0
    random.shuffle(training_data)
    np.save("training_data.npy", training_data)

if (os.path.exists("validation_data.npy")):
    validation_data = np.load("validation_data.npy")
else:
    validation_data_1 = load_images(path_val_1,[1,0],imsize)
    validation_data_0 = load_images(path_val_0,[0,1],imsize)
    validation_data = validation_data_1 + validation_data_0
    random.shuffle(validation_data)
    np.save("validation_data.npy", validation_data)

#img = Image.fromarray(training_data[5][0], 'RGB')
##img.save('my.png')
#img.show()

aug_training_data = augment_data(training_data,augementation_factor=5)



#img = Image.fromarray(aug_training_data[2][0], 'RGB')
###img.save('my.png')
#img.show()

training_gray_data = rgb2gray(aug_training_data)
training_std_color_data = stdimage(aug_training_data,maxfeature)
training_std_gray_data = stdimage(training_gray_data,maxfeature)

if (os.path.exists('{}.sav'.format("scaler"))) and (os.path.exists('{}.sav'.format("pca"))) :
    scaler = pickle.load(open("scaler.sav", 'rb'))
    pca = pickle.load(open("pca.sav", 'rb'))
    print("scaler and pca model loaded!")
    scalert, pcat, training_pca_data = pcafun(training_gray_data,imsize=imsize,scaler=scaler,pca=pca,val=1)
else:
    scaler, pca, training_pca_data = pcafun(training_gray_data,imsize,train=1)
    filename_scaler = '{}.sav'.format("scaler")
    pickle.dump(scaler, open(filename_scaler, 'wb'))
    filename_pca = '{}.sav'.format("pca")
    pickle.dump(pca, open(filename_pca, 'wb'))
    



val_gray_data = rgb2gray(validation_data)
val_std_color_data = stdimage(validation_data,maxfeature)
val_std_gray_data = stdimage(val_gray_data,maxfeature)
vals,valp,val_pca_data = pcafun(val_gray_data,imsize=imsize,scaler=scaler,pca=pca,val=1)

#plt.imshow(training_gray_data[5][0])
model_name_color = '{}_model'.format('colornet')
colornet = convnet_class(imsize=imsize,data_train=training_std_color_data,data_val=val_std_color_data,numlayer=4,neuron=[32,64,200,1024],model_name=model_name_color,color=1)
#colornet.model_perf()
#colornet.val_acc

model_name_gray = '{}_model'.format('graynet')
graynet = convnet_class(imsize=imsize,data_train=training_std_gray_data,data_val=val_std_gray_data,numlayer=4,neuron=[32,64,200,1024],model_name=model_name_gray,color=0)
#graynet.model_perf()
#graynet.val_acc

rf_model_name = '{}_model'.format('rfpca')
rf = rf_class(data_train=training_pca_data,data_val=val_pca_data,model_name=rf_model_name,n_estimators=500)
#rf.val_acc





#Y_train_ens_pred = ensemble_model(colornet.Y_train_pred_nn,graynet.Y_train_pred_nn,rf.Y_train_pred_rf)
#Y_val_ens_pred = ensemble_model(colornet.Y_val_pred_nn,graynet.Y_val_pred_nn,rf.Y_val_pred_rf)
#ens_train_acc, ens_train_pres, ens_train_recall, ens_train_fscore, ens_train_auc =  model_perf(np.array(colornet.Y), Y_train_ens_pred)
#ens_val_acc, ens_val_pres, ens_val_recall, ens_val_fscore, ens_val_auc =  model_perf(np.array(colornet.Y_val), Y_val_ens_pred)
## Perform test cases
#path_test = os.path.join(default_path,"Images","test_images")
#test_data, real_test_image = load_test_images(path_test,[0,0])
#
#test_gray_data = rgb2gray(test_data)
#test_std_color_data = stdimage(test_data,maxfeature)
#test_std_gray_data = stdimage(test_gray_data,maxfeature)
#tests,testp,test_pca_data = pcafun(test_gray_data,imsize=imsize,scaler=scaler,pca=pca,test=1)
#
#colornet.test_predict(test_std_color_data)
#Y_test_pred_nn_color = colornet.Y_test_pred_nn
#
#graynet.test_predict(test_std_gray_data)
#Y_test_pred_nn_gray = graynet.Y_test_pred_nn
#
#rf.test_predict(test_pca_data)
#Y_test_pred_rf = rf.Y_test_pred_rf

#Y_test_pred_ens = ensemble_model(Y_test_pred_nn_color,Y_test_pred_nn_gray,Y_test_pred_rf)

#fig = plt.figure()
#for num in range (0,len(test_data)):
#    img_data = real_test_image[num][0]
#    y = fig.add_subplot(4,4,num+1)
#    if np.argmax(Y_test_pred_nn_color[num,:]) == 0:
#        str_label_cnet = "Colornet: Car"
#    else:
#        str_label_cnet = "Colornet: NotCar"
#    if np.argmax(Y_test_pred_nn_gray[num,:]) == 0:
#        str_label_gray = "Graynet: Car"
#    else:
#        str_label_gray = "Graynet: NotCar"
#    if np.argmax(Y_test_pred_rf[num,:]) == 0:
#        str_label_rf = "RF: Car"
#    else:
#        str_label_rf = "RF: NotCar"
#    if np.argmax(Y_test_pred_ens[num,:]) == 0:
#        str_label_ens = "ENS: Car"
#    else:
#        str_label_ens = "ENS: NotCar"
#    str_label = str_label_cnet + ";" + str_label_gray + ";" + str_label_rf + ";" + str_label_ens
#    y.imshow(img_data)
#    plt.title(str_label_ens)
#    y.axes.get_xaxis().set_visible(False)
#    y.axes.get_yaxis().set_visible(False)
#plt.show()
#    
    
    
    