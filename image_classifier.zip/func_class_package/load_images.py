# -*- coding: utf-8 -*-
"""
Created on Tue Jul 17 22:37:20 2018

@author: ranas
"""
import os
import cv2
import numpy as np


   
def load_images(pathvar,label,imsize=50):
    data_read = []
    for imgname in os.listdir(pathvar):
        imgext = imgname.split(".")[-1]
        if imgext == "jpg" or imgext == "jpeg" or imgext == "png":
            imgpath = os.path.join(pathvar,imgname)
            img = cv2.resize(cv2.imread(imgpath, cv2.IMREAD_COLOR), (imsize,imsize))
            data_read.append([np.array(img), np.array(label)])
    return data_read

def load_test_images(pathvar,label,imsize=50):
    data_read = []
    image_realsize = []
    for imgname in os.listdir(pathvar):
        imgext = imgname.split(".")[-1]
        if imgext == "jpg" or imgext == "jpeg" or imgext == "png":
            imgpath = os.path.join(pathvar,imgname)
            img = cv2.resize(cv2.imread(imgpath, cv2.IMREAD_COLOR), (imsize,imsize))
            img_real = cv2.imread(imgpath, cv2.IMREAD_COLOR)
            data_read.append([np.array(img), np.array(label)])
            image_realsize.append([np.array(img_real)])
    return data_read, image_realsize

def load_test_images_user(pathvar,imgname,label,imsize=50):
    data_read = []
    image_realsize = []
    imgext = imgname.split(".")[-1]
    if imgext == "jpg" or imgext == "jpeg" or imgext == "png":
        imgpath = os.path.join(pathvar,imgname)
        img = cv2.resize(cv2.imread(imgpath, cv2.IMREAD_COLOR), (imsize,imsize))
        img_real = cv2.imread(imgpath, cv2.IMREAD_COLOR)
        data_read.append([np.array(img), np.array(label)])
        image_realsize.append([np.array(img_real)])
    return data_read, image_realsize