import os
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle

## Combine the predictions to get the majority vote
def ensemble_model(cnet_pred,gnet_pred,rf_pred):
    raw_ens = np.array(cnet_pred)+np.array(gnet_pred)+np.array(rf_pred)
    max_ind = np.argmax(raw_ens, axis=1)
    row,col = np.shape(raw_ens)
    out_pred = np.zeros(shape=(row,col))
    for i in range(0,row):
        out_pred[i,max_ind[i]] = 1
    return out_pred

def model_perf(ytrue,ypred):
    accuracy_value =   metrics.accuracy_score(ytrue,ypred)
    precision_value =   metrics.precision_score(ytrue,ypred,average=None)[0]
    recall_value =   metrics.recall_score(ytrue,ypred,average=None)[0]
    fscore_value =   metrics.f1_score(ytrue,ypred,average=None)[0]
    auc_value =   metrics.roc_auc_score(ytrue,ypred,average=None)[0]
    return accuracy_value,precision_value,recall_value,fscore_value,auc_value