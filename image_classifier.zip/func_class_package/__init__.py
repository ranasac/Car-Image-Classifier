# -*- coding: utf-8 -*-
"""
Created on Tue Jul 17 23:03:49 2018

@author: ranas
"""

import os
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle
