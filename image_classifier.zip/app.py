import os
import numpy as np
from flask import Flask, render_template, request
#from flask.ext.uploads import UploadSet, configure_uploads, IMAGES
from flask_uploads import UploadSet, configure_uploads, IMAGES

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT_PATH)
import image_classifier_4
from func_class_package.load_images import load_images, load_test_images, load_test_images_user
from func_class_package.preprocess_image import augment_data, rgb2gray, stdimage, pcafun
from  func_class_package.cnn_class import convnet_class
from  func_class_package.rf_class import rf_class
from  func_class_package.ensemble_model import ensemble_model, model_perf


app = Flask(__name__)

folder = 'testimage'
if (os.path.exists(folder)):
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            #elif os.path.isdir(file_path): shutil.rmtree(file_path)
        except Exception as e:
            print(e)

photos = UploadSet('photos', IMAGES)

app.config['UPLOADED_PHOTOS_DEST'] = 'testimage'
configure_uploads(app, photos)


@app.route('/', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST' and 'photo' in request.files:
        filename = photos.save(request.files['photo'])
        path_test_user = os.path.join(image_classifier_4.default_path,"testimage")
        test_data_user, real_test_image_user = load_test_images_user(path_test_user,filename,[0,0])
        
        test_gray_data_user = rgb2gray(test_data_user)
        test_std_color_data_user = stdimage(test_data_user,image_classifier_4.maxfeature)
        test_std_gray_data_user = stdimage(test_gray_data_user,image_classifier_4.maxfeature)
        tests,testp,test_pca_data_user = pcafun(test_gray_data_user,imsize=image_classifier_4.imsize,scaler=image_classifier_4.scaler,pca=image_classifier_4.pca,test=1)
        
        image_classifier_4.colornet.test_predict(test_std_color_data_user)
        Y_test_pred_nn_color_user = image_classifier_4.colornet.Y_test_pred_nn
        
        image_classifier_4.graynet.test_predict(test_std_gray_data_user)
        Y_test_pred_nn_gray_user = image_classifier_4.graynet.Y_test_pred_nn
        
        image_classifier_4.rf.test_predict(test_pca_data_user)
        Y_test_pred_rf_user = image_classifier_4.rf.Y_test_pred_rf
        
        Y_test_pred_ens_user = ensemble_model(Y_test_pred_nn_color_user,Y_test_pred_nn_gray_user,Y_test_pred_rf_user)
        if np.argmax(Y_test_pred_ens_user[0,:]) == 0:
            str_label_ens_user = "Car"
        else:
            str_label_ens_user = "NotCar"
       
        return ("The Uploaded Picture is ---->  " + str_label_ens_user)
    return render_template('upload.html')

app.run(host='0.0.0.0', port=5000)

#if __name__ == '__main__':
#    app.run()